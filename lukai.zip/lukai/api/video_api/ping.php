<?php
/**
 * 检查是否通讯成功
 */
defined('IN_PHPCMS') or exit('No permission resources.'); 
echo json_encode(array('msg'=>'Ping success','100'));
?>