<?php

/*Language Format:
Add a new file(.lang.php) with your module name at /phpcms/languages/
translation save at the array:$LANG
*/
$LANG['email_title'] = 'email_title';
$LANG['email_contents'] = 'email_contents';
$LANG['emailpost_name'] = 'emailpost_name';
$LANG['email_contents_add'] = 'email_contents_add';
$LANG['add_contents'] =	'add_contents';
$LANG['edit_contents'] = 'edit_contents';
$LANG['contents'] =	'contents';
$LANG['emailgroupname'] = 'emailgroupname';
$LANG['operation'] = 'operation';
$LANG['emailname'] = 'emailname';
$LANG['username'] = 'username';
$LANG['publish_time'] = 'publish_time';
$LANG['delete_select'] = 'delete_select';
$LANG['excel_upload'] = 'excel_upload';
$LANG['tablename'] = 'tablename';
$LANG['field'] = 'field';
$LANG['confirm_import'] = 'confirm_import';
$LANG['emailpost_type_name'] = 'emailpost_type_name';
$LANG['emailpost_description'] = 'emailpost_description';
