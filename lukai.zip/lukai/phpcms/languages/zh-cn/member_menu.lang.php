<?php
$LANG['member_init'] = '管理中心';
$LANG['account_manage'] = '账号管理';
$LANG['favorite'] = '收藏';
$LANG['pay'] = '在线充值';
$LANG['business_centre'] = '商务中心';
$LANG['wanggan'] = '会员数据导入';
$LANG['business_centre'] = '商务中心';
$LANG['ask_center'] = '问答中心';
?>