<?php
return array (
  1 => 
  array (
    'siteid' => '1',
    'name' => '默认站点',
    'dirname' => '',
    'domain' => 'http://lukai.worldmall.com/',
    'site_title' => '路凯店铺',
    'keywords' => '路凯 箱包',
    'description' => '路凯店铺',
    'release_point' => '',
    'default_style' => 'default',
    'template' => 'default',
    'setting' => 'array (
  \'upload_maxsize\' => \'2048\',
  \'upload_allowext\' => \'jpg|jpeg|gif|bmp|png|doc|docx|xls|xlsx|ppt|pptx|pdf|txt|rar|zip|swf\',
  \'watermark_enable\' => \'1\',
  \'watermark_minwidth\' => \'300\',
  \'watermark_minheight\' => \'300\',
  \'watermark_img\' => \'statics/images/water//mark.png\',
  \'watermark_pct\' => \'85\',
  \'watermark_quality\' => \'80\',
  \'watermark_pos\' => \'9\',
)',
    'uuid' => '74701ef6-1ac1-11e3-8902-5c63bf869f5d',
    'url' => 'http://lukai.worldmall.com/',
  ),
);
?>