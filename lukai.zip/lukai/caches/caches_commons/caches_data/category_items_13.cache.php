<?php
return array (
  12 => '0',
  30 => '1',
  31 => '3',
);
?>