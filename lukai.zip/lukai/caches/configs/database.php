<?php

return array (
	'default' => array (
		'hostname' => 'localhost',
		'database' => 'lukai',
		'username' => 'root',
		'password' => '123456',
		'tablepre' => 'lk_',
		'charset' => 'utf8',
		'type' => 'mysql',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
);

?>