<?php
return array (
  0 => 
  array (
    'typeid' => '1',
    'siteid' => '1',
    'module' => 'search',
    'modelid' => '1',
    'name' => '新闻',
    'parentid' => '0',
    'typedir' => '',
    'url' => '',
    'template' => '',
    'listorder' => '1',
    'description' => '新闻模型搜索',
  ),
  1 => 
  array (
    'typeid' => '3',
    'siteid' => '1',
    'module' => 'search',
    'modelid' => '3',
    'name' => '图片',
    'parentid' => '0',
    'typedir' => '',
    'url' => '',
    'template' => '',
    'listorder' => '2',
    'description' => '图片模型搜索',
  ),
  2 => 
  array (
    'typeid' => '2',
    'siteid' => '1',
    'module' => 'search',
    'modelid' => '2',
    'name' => '下载',
    'parentid' => '0',
    'typedir' => '',
    'url' => '',
    'template' => '',
    'listorder' => '3',
    'description' => '下载模型搜索',
  ),
  3 => 
  array (
    'typeid' => '52',
    'siteid' => '1',
    'module' => 'search',
    'modelid' => '0',
    'name' => '专题',
    'parentid' => '0',
    'typedir' => 'special',
    'url' => '',
    'template' => '',
    'listorder' => '4',
    'description' => '专题',
  ),
);
?>