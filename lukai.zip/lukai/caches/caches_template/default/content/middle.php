<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><div class="submenu">
			<ul class="links fl">
				<li><a href="http://provence-fashion.taobao.com/" target="_blank">网上商城<i class="mall"></i></a></li>
				<li><a href="http://provence-fashion.taobao.com/" target="_blank">在线客服<i class="service"></i></a></li>
				<li><a href="http://weibo.com/signup/signup.php?inviteCode=3735204243" target="_blank">微博互动<i class="weibo"></i></a></li>
			</ul>
			<div class="search">
				<form name="search" id="" action="" method="get">
                                        <input type="submit" id="submit" class="btn" />
                                        <input name="q" class="input" type="text"   />
                                        <input type="hidden" value="search" name="m" />
                                        <input type="hidden" value="index" name="c" />
                                        <input type="hidden" value="init" name="a" />
                                        <input type="hidden" name="siteid" value="1" /> 
                                        <input type="hidden" name="typeid" value="53" /> 
                                  </form>
			</div>
		</div>