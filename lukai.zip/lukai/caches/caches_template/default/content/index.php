<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template("content","header"); ?>
<div id="banner"><h1>路凯Deluxe</h1></div>
<?php include template("content","footer"); ?>

